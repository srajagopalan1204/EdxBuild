# summarization helpers go here
